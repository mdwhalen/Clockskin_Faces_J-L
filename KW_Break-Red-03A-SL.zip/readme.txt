KROLLWare ClockSkin:

     Name: KW_Break-03A-SL
     Date: 14-Aug-2020
     Desc: Break - Sports watch - Red
    eMail: krollware@gmail.com

Credits:
   
    Watch: https://www.breakwatches.com/

  Font(s): https://www.1001fonts.com/netron-font.html

 Graphics: 

    Notes: 




