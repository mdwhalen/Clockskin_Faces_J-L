KROLLWare ClockSkin:

     Name: KW_Break-04A-SL
     Date: 14-Aug-2020
     Desc: Break - Sports watch - Yellow
    eMail: krollware@gmail.com

Credits:
   
    Watch: https://www.breakwatches.com/

  Font(s): https://www.1001fonts.com/netron-font.html

 Graphics: 

    Notes: 




