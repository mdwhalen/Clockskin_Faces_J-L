KROLLWare ClockSkin:

     Name: KW_Tag_Heuer_Monaco-02A-SL
     Date: 23-Jun-2020
     Desc: Tag Heuer Monaco Brown Louvers
    eMail: krollware@gmail.com

Credits:

    Watch: https://www.luxuo.com/style/watches/tag-heuer-monaco-through-time-limited-edition-celebrates-the-groovy-70s.html

  Font(s): https://www.1001fonts.com/adequate-font.html
           https://www.dafont.com/aero-matics.font
           https://www.dafontfree.net/freefonts-napoli-serial-medium-f134125.htm

 Graphics: https://www.freepik.com/free-photos-vectors/louvers
           
    Notes: Requested By: carlton_86



