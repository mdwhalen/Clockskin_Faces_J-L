KROLLWare ClockSkin:

     Name: KW_Graphics-06B-UL
     Date: 18-Jul-2020
     Desc: Spinning Graphics
    eMail: krollware@gmail.com

Credits:

  Font(s): Arial

 Graphics: https://www.pinterest.it/pin/508343876671233977/

    Notes: 




